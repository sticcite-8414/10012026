#!/usr/bin/env bash
set -Eeuo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
COMMON="$SCRIPT_DIR/run-week-lab-common.sh"
if [ ! -f "$COMMON" ]; then
  echo "ERROR: Missing required local file: $COMMON" >&2
  exit 1
fi
chmod +x "$COMMON"
PHASE=8 WEEK=08 LAB_TITLE="Federated Threat Intelligence Network" exec "$COMMON" "$@"

