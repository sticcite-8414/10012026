# SEAS-8414 Phase 8 Blackboard Package

This ZIP is prepared for Blackboard course-content upload after the release-ready
student lab package gate passes.

Contents:

- `runtime/` with the curated student lab runtime ZIP
- `MANIFEST.json` and `SHA256SUMS`

Quick start for Phase 8:

```bash
mkdir -p "$HOME/seas8414-week08"
cd "$HOME/seas8414-week08"
unzip seas8414-blackboard-week-08-2026.05.0_4e76a52f_aws8414.zip
cd seas8414-blackboard-week-08-2026.05.0_4e76a52f_aws8414
make week08
```

The Makefile calls `run-week08-lab.sh`. It downloads the public ZIP if needed,
extracts the nested runtime ZIP, starts Docker Compose, runs the Week 08 API
workflow, saves evidence under `lab-results/week-08/evidence/`, writes
`lab-results/week-08/index.html`, and cleans up containers with
`docker compose down -v --remove-orphans` at exit.

Do not run the Docker lab from `/tmp` on macOS. Docker Desktop and Colima can reject bind mounts
from temporary directories. Use a normal user-writable folder such as `$HOME/seas8414-week08`,
`Downloads`, or `Desktop`.

Manual runtime extraction:

```bash
unzip runtime/seas8414-student-lab-2026.05.0+4e76a52f.aws8414.zip -d runtime-extracted
cd runtime-extracted/seas8414-student-lab-2026.05.0+4e76a52f.aws8414/student-lab
```

Release ID: `2026.05.0+4e76a52f.aws8414`
